# Лабораторная работа №1. Введение в Spring Boot

**Цель работы:** получить практические навыки работы с Spring Framework.

## Описание

Простое веб-приложение на Spring Boot для хранения сообщений (заметок).
Сообщения хранятся в памяти в списке `List<String>` и управляются через HTTP-запросы
(операции CRUD: Create, Read, Update, Delete).

- Язык: Java 21
- Сборка: Maven
- Spring Boot: 3.2.3
- Зависимость: `spring-boot-starter-web`

## Структура проекта

```
demo/
├── pom.xml
└── src/main/
    ├── java/com/example/demo/
    │   ├── DemoApplication.java     — точка входа в приложение
    │   └── MessageController.java   — REST-контроллер сообщений
    └── resources/
        └── application.properties
```

## API

| Метод  | URL                  | Описание                               |
|--------|----------------------|----------------------------------------|
| GET    | `/`                  | Приветствие `Hello, World!`            |
| GET    | `/messages`          | Получить все сообщения                 |
| POST   | `/messages`          | Опубликовать сообщение                 |
| PUT    | `/messages/{index}`  | Изменить сообщение по индексу          |
| DELETE | `/messages/{index}`  | Удалить сообщение по индексу           |
| DELETE | `/messages`          | Очистить все сообщения *(доп. задание)* |
| GET    | `/messages/count`    | Количество сообщений *(доп. задание)*  |

## Дополнительное задание

Реализованы два дополнительных метода:

1. **Вариант 1 — `clearAllMessages()`** — очищает список всех сообщений.
   ```java
   @DeleteMapping("/messages")
   public String clearAllMessages() {
       userMessages.clear();
       return "All messages cleared successfully!";
   }
   ```

2. **Вариант 6 — `countMessages()`** — возвращает общее количество сообщений в списке.
   ```java
   @GetMapping("/messages/count")
   public int countMessages() {
       return userMessages.size();
   }
   ```

## Запуск

1. Открыть проект в IntelliJ IDEA как Maven-проект.
2. Запустить класс `DemoApplication`.
3. Приложение будет доступно по адресу http://localhost:8080

## Проверка (PowerShell)

```powershell
# Приветствие
Invoke-RestMethod -Uri "http://localhost:8080/"

# Все сообщения
Invoke-RestMethod -Uri "http://localhost:8080/messages"

# Публикация сообщения
$message = "Your message here"
Invoke-RestMethod -Uri "http://localhost:8080/messages" -Method Post -Body $message -ContentType "application/json"

# Обновление сообщения
$index = 0
$message = "Updated message"
Invoke-RestMethod -Uri "http://localhost:8080/messages/$index" -Method Put -Body $message -ContentType "application/json"

# Удаление сообщения
$index = 0
Invoke-RestMethod -Uri "http://localhost:8080/messages/$index" -Method Delete

# Количество сообщений (доп. задание)
Invoke-RestMethod -Uri "http://localhost:8080/messages/count"

# Очистка всех сообщений (доп. задание)
Invoke-RestMethod -Uri "http://localhost:8080/messages" -Method Delete
```

## Вывод

В ходе работы был создан проект Spring Boot через Spring Initializr, подключена зависимость
`spring-boot-starter-web` и разработан REST-контроллер `MessageController`, обрабатывающий
GET, POST, PUT и DELETE запросы. Дополнительно реализованы методы очистки списка сообщений
и подсчёта их количества. Получены практические навыки работы с Spring Framework.
