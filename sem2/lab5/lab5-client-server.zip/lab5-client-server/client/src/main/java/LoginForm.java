import javax.swing.*;
import java.awt.*;
import java.util.Map;

public class LoginForm extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;

    public LoginForm() {
        // UI компоненты
        setTitle("Login");
        setSize(320, 170);
        setLocationRelativeTo(null); // окно по центру экрана
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(3, 2, 8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        // Поля ввода для логина
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        loginButton = new JButton("Login");

        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        panel.add(new JPanel()); // Пустое место
        panel.add(loginButton);
        add(panel);

        // Вход по нажатию Enter
        getRootPane().setDefaultButton(loginButton);

        // Обработчик авторизации
        loginButton.addActionListener(e -> login());
    }

    private void login() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        ApiClient api = new ApiClient(username, password);

        try {
            // Проверяем логин и пароль запросом к серверу
            ApiClient.Response response = api.getMe();
            if (response.code == 200) {
                Map<String, String> me = ApiClient.parseObject(response.body);
                // Если авторизация успешна, открываем главную форму
                new TaskManagerForm(api, me.get("username"), me.get("role")).setVisible(true);
                dispose(); // Закрываем форму авторизации
            } else {
                JOptionPane.showMessageDialog(this, "Неверный логин или пароль",
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Сервер недоступен. Запустите серверное приложение.",
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                // Системный внешний вид окон
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
            }
            new LoginForm().setVisible(true);
        });
    }
}
