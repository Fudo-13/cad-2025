import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class TaskManagerForm extends JFrame {

    // Колонки таблицы
    private static final String[] COLUMNS =
            {"ID", "Описание", "Категория", "Приоритет", "Создана", "Автор", "Статус", "Подзадач"};
    private static final int COL_ID = 0;
    private static final int COL_PRIORITY = 3;

    private final ApiClient api;
    private final String role;

    private DefaultTableModel tableModel;
    private JTable taskTable;
    private TableRowSorter<DefaultTableModel> sorter;
    private JComboBox<String> sortBox;
    private JLabel statusLabel;

    public TaskManagerForm(ApiClient api, String username, String role) {
        this.api = api;
        this.role = role;

        setTitle("Task Manager");
        setSize(900, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));

        add(createTopPanel(username), BorderLayout.NORTH);
        add(createTable(), BorderLayout.CENTER);
        add(createBottomPanel(), BorderLayout.SOUTH);

        loadTasks(); // Загрузка задач из API
    }

    // ===================== Интерфейс =====================

    private JPanel createTopPanel(String username) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 0, 8));

        JLabel userLabel = new JLabel("Пользователь: " + username + " (" + role + ")");
        userLabel.setFont(userLabel.getFont().deriveFont(Font.BOLD, 14f));
        panel.add(userLabel, BorderLayout.WEST);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        // Доп. задание: сортировка задач
        right.add(new JLabel("Сортировка:"));
        sortBox = new JComboBox<>(new String[]{
                "По ID", "По описанию", "По приоритету (сначала высокий)",
                "По дате создания (сначала новые)", "По статусу", "По категории"});
        sortBox.addActionListener(e -> applySort());
        right.add(sortBox);

        JButton refreshButton = new JButton("Обновить задачи");
        refreshButton.addActionListener(e -> loadTasks());
        right.add(refreshButton);

        JButton logoutButton = new JButton("Выйти");
        logoutButton.addActionListener(e -> {
            dispose();
            new LoginForm().setVisible(true);
        });
        right.add(logoutButton);

        panel.add(right, BorderLayout.EAST);
        return panel;
    }

    private JScrollPane createTable() {
        // Таблица только для чтения
        tableModel = new DefaultTableModel(COLUMNS, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }

            @Override
            public Class<?> getColumnClass(int column) {
                // ID и количество подзадач - числа, чтобы сортировка была числовой
                return (column == COL_ID || column == 7) ? Long.class : String.class;
            }
        };

        taskTable = new JTable(tableModel);
        taskTable.setRowHeight(24);
        taskTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        taskTable.getColumnModel().getColumn(1).setPreferredWidth(250);

        // Сортировка по клику на заголовок колонки
        sorter = new TableRowSorter<>(tableModel);
        // Приоритет сортируется по смыслу: Low < Medium < High
        sorter.setComparator(COL_PRIORITY, Comparator.comparingInt(TaskManagerForm::priorityWeight));
        taskTable.setRowSorter(sorter);

        JScrollPane scrollPane = new JScrollPane(taskTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
        return scrollPane;
    }

    private JPanel createBottomPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(0, 8, 8, 8));

        // Доп. задание: добавление задачи из клиента
        JPanel addPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        addPanel.setBorder(BorderFactory.createTitledBorder("Новая задача"));

        JTextField descriptionField = new JTextField(22);
        JComboBox<String> categoryBox = new JComboBox<>(new String[]{"Study", "Work", "Personal"});
        JComboBox<String> priorityBox = new JComboBox<>(new String[]{"Low", "Medium", "High"});
        priorityBox.setSelectedItem("Medium");
        JButton addButton = new JButton("Добавить");

        addPanel.add(new JLabel("Описание:"));
        addPanel.add(descriptionField);
        addPanel.add(new JLabel("Категория:"));
        addPanel.add(categoryBox);
        addPanel.add(new JLabel("Приоритет:"));
        addPanel.add(priorityBox);
        addPanel.add(addButton);

        addButton.addActionListener(e -> {
            addTask(descriptionField.getText(),
                    (String) categoryBox.getSelectedItem(),
                    (String) priorityBox.getSelectedItem());
            descriptionField.setText("");
        });

        // Доп. задание: удаление задачи из клиента (только MODERATOR и ADMIN)
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton deleteButton = new JButton("Удалить выбранную");
        boolean canDelete = role.equals("MODERATOR") || role.equals("ADMIN");
        deleteButton.setEnabled(canDelete);
        if (!canDelete) {
            deleteButton.setToolTipText("Удалять задачи может только MODERATOR или ADMIN");
        }
        deleteButton.addActionListener(e -> deleteSelectedTask());
        actions.add(deleteButton);

        // Добавлять задачи не может AUDITOR
        if (role.equals("AUDITOR")) {
            addButton.setEnabled(false);
            addButton.setToolTipText("AUDITOR не может добавлять задачи");
        }

        statusLabel = new JLabel(" ");

        panel.add(addPanel, BorderLayout.CENTER);
        panel.add(actions, BorderLayout.EAST);
        panel.add(statusLabel, BorderLayout.SOUTH);
        return panel;
    }

    // ===================== Работа с сервером =====================

    private void loadTasks() {
        try {
            ApiClient.Response response = api.getTasks();
            if (response.code == 200) {
                // Доп. задание: вывод дополнительных данных из БД
                List<Map<String, String>> tasks = ApiClient.parseArray(response.body);
                tableModel.setRowCount(0);
                for (Map<String, String> task : tasks) {
                    tableModel.addRow(new Object[]{
                            Long.parseLong(task.get("id")),
                            task.get("description"),
                            task.get("category"),
                            task.get("priority"),
                            task.get("createdAt"),
                            task.get("author"),
                            "true".equals(task.get("completed")) ? "Completed" : "Pending",
                            Long.parseLong(task.getOrDefault("subTasks", "0"))
                    });
                }
                applySort();
                statusLabel.setText("Загружено задач: " + tasks.size());
            } else {
                JOptionPane.showMessageDialog(this, "Ошибка загрузки задач (код " + response.code + ")");
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Сервер недоступен");
        }
    }

    private void addTask(String description, String category, String priority) {
        if (description.isBlank()) {
            JOptionPane.showMessageDialog(this, "Введите описание задачи");
            return;
        }
        try {
            ApiClient.Response response = api.addTask(description, category, priority);
            if (response.code == 200) {
                statusLabel.setText("Задача добавлена");
                loadTasks();
            } else if (response.code == 403) {
                JOptionPane.showMessageDialog(this, "Нет прав на добавление задач");
            } else {
                JOptionPane.showMessageDialog(this, "Ошибка добавления (код " + response.code + ")");
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Сервер недоступен");
        }
    }

    private void deleteSelectedTask() {
        int viewRow = taskTable.getSelectedRow();
        if (viewRow < 0) {
            JOptionPane.showMessageDialog(this, "Выберите задачу в таблице");
            return;
        }
        int row = taskTable.convertRowIndexToModel(viewRow);
        long id = (Long) tableModel.getValueAt(row, COL_ID);
        String description = (String) tableModel.getValueAt(row, 1);

        int answer = JOptionPane.showConfirmDialog(this,
                "Удалить задачу \"" + description + "\"?", "Подтверждение", JOptionPane.YES_NO_OPTION);
        if (answer != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            ApiClient.Response response = api.deleteTask(id);
            if (response.code == 200) {
                statusLabel.setText("Задача удалена");
                loadTasks();
            } else if (response.code == 403) {
                JOptionPane.showMessageDialog(this, "Нет прав на удаление задач");
            } else {
                JOptionPane.showMessageDialog(this, "Ошибка удаления (код " + response.code + ")");
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Сервер недоступен");
        }
    }

    // ===================== Сортировка =====================

    private void applySort() {
        int column;
        SortOrder order = SortOrder.ASCENDING;
        switch (sortBox.getSelectedIndex()) {
            case 1 -> column = 1;                                       // описание
            case 2 -> { column = COL_PRIORITY; order = SortOrder.DESCENDING; }
            case 3 -> { column = 4; order = SortOrder.DESCENDING; }     // дата создания
            case 4 -> column = 6;                                       // статус
            case 5 -> column = 2;                                       // категория
            default -> column = COL_ID;
        }
        sorter.setSortKeys(List.of(new RowSorter.SortKey(column, order)));
    }

    private static int priorityWeight(Object priority) {
        return switch (String.valueOf(priority)) {
            case "High" -> 3;
            case "Medium" -> 2;
            case "Low" -> 1;
            default -> 0;
        };
    }
}
