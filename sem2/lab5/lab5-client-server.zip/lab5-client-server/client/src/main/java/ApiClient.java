import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Base64;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Класс для отправки запросов на сервер (http://localhost:8080/api)
public class ApiClient {

    private static final String BASE_URL = "http://localhost:8080";

    private final String authHeader;

    // Ответ сервера: код и тело
    public static class Response {
        public final int code;
        public final String body;

        public Response(int code, String body) {
            this.code = code;
            this.body = body;
        }
    }

    public ApiClient(String username, String password) {
        // Логин и пароль кодируются в Base64 для заголовка Authorization: Basic
        this.authHeader = Base64.getEncoder()
                .encodeToString((username + ":" + password).getBytes(StandardCharsets.UTF_8));
    }

    // Отправка HTTP-запроса
    private Response send(String method, String path, String jsonBody) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) URI.create(BASE_URL + path).toURL().openConnection();
        conn.setRequestMethod(method);
        conn.setRequestProperty("Authorization", "Basic " + authHeader);
        conn.setRequestProperty("Accept", "application/json");

        if (jsonBody != null) {
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            try (OutputStream os = conn.getOutputStream()) {
                os.write(jsonBody.getBytes(StandardCharsets.UTF_8));
            }
        }

        int code = conn.getResponseCode();
        System.out.println(method + " " + path + " -> Response Code: " + code);

        InputStream stream = code < 400 ? conn.getInputStream() : conn.getErrorStream();
        String body = "";
        if (stream != null) {
            body = new String(stream.readAllBytes(), StandardCharsets.UTF_8);
            stream.close();
        }
        conn.disconnect();
        return new Response(code, body);
    }

    // GET /api/me - проверка логина и получение роли
    public Response getMe() throws IOException {
        return send("GET", "/api/me", null);
    }

    // GET /api - список задач
    public Response getTasks() throws IOException {
        return send("GET", "/api", null);
    }

    // POST /api - добавление задачи
    public Response addTask(String description, String category, String priority) throws IOException {
        String json = "{"
                + "\"description\":\"" + escape(description) + "\","
                + "\"category\":\"" + escape(category) + "\","
                + "\"priority\":\"" + escape(priority) + "\""
                + "}";
        return send("POST", "/api", json);
    }

    // DELETE /api/{id} - удаление задачи
    public Response deleteTask(long id) throws IOException {
        return send("DELETE", "/api/" + id, null);
    }

    // ===================== Простой разбор JSON =====================

    // Разбор массива объектов: [{...},{...}]
    public static List<Map<String, String>> parseArray(String json) {
        List<Map<String, String>> result = new ArrayList<>();
        Matcher matcher = Pattern.compile("\\{[^{}]*\\}").matcher(json);
        while (matcher.find()) {
            result.add(parseObject(matcher.group()));
        }
        return result;
    }

    // Разбор одного объекта: {"key":"value","key2":123}
    public static Map<String, String> parseObject(String json) {
        Map<String, String> result = new LinkedHashMap<>();
        Pattern pattern = Pattern.compile("\"(\\w+)\"\\s*:\\s*(\"((?:[^\"\\\\]|\\\\.)*)\"|[^,}]+)");
        Matcher matcher = pattern.matcher(json);
        while (matcher.find()) {
            String key = matcher.group(1);
            String value = matcher.group(3) != null ? unescape(matcher.group(3)) : matcher.group(2).trim();
            if (value.equals("null")) {
                value = "";
            }
            result.put(key, value);
        }
        return result;
    }

    private static String escape(String text) {
        return text.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String unescape(String text) {
        return text.replace("\\\"", "\"").replace("\\n", " ").replace("\\\\", "\\");
    }
}
