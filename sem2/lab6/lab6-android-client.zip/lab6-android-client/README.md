# Лабораторная работа №6. Разработка клиента под Android

**Цель работы:** получить практические навыки работы с Spring Framework. Разработать клиент под Android.

## Описание

Android-приложение, которое авторизуется на сервере Spring Boot и выводит список задач
(ToDo List). Данные загружаются через REST API `GET /api` с помощью библиотеки Retrofit.

```
Android-эмулятор  --HTTP (Basic Auth)-->  http://10.0.2.2:8080/api  -->  Spring Boot  -->  PostgreSQL
```

`10.0.2.2` — специальный адрес, по которому эмулятор Android обращается к `localhost`
компьютера, на котором запущен сервер.

## Структура репозитория

```
lab6-android-client/
├── server/                     — серверное приложение Spring Boot (из ЛР5, с REST API /api)
└── android-client/             — клиент под Android
    ├── build.gradle.kts
    ├── settings.gradle.kts
    └── app/
        ├── build.gradle.kts    — зависимости (Retrofit, Gson, RecyclerView, ...)
        └── src/main/
            ├── AndroidManifest.xml
            ├── java/com/example/myapplication/
            │   ├── LoginActivity.java        — экран входа
            │   ├── TaskManagerActivity.java  — экран со списком задач
            │   ├── TaskAdapter.java          — адаптер для RecyclerView
            │   ├── Task.java                 — модель задачи
            │   └── TaskApi.java              — описание REST API для Retrofit
            └── res/
                ├── layout/
                │   ├── activity_login.xml
                │   ├── activity_task_manager.xml
                │   └── item_task.xml
                └── xml/
                    └── network_security_config.xml
```

## Что сделано

1. **Зависимости** в `app/build.gradle.kts`: `appcompat`, `material`, `constraintlayout`,
   `retrofit`, `converter-gson`, `recyclerview`.
2. **network_security_config.xml** разрешает незашифрованный HTTP-трафик к адресу `10.0.2.2`.
3. **AndroidManifest.xml**: подключён конфиг сети, объявлены `LoginActivity` (точка входа)
   и `TaskManagerActivity`, добавлено разрешение `INTERNET`.
4. **Макеты**: форма входа (`activity_login.xml`), экран со списком (`activity_task_manager.xml`)
   и элемент списка (`item_task.xml`).
5. **LoginActivity** кодирует `логин:пароль` в Base64 и передаёт его в `TaskManagerActivity`
   через `Intent`.
6. **TaskManagerActivity** через Retrofit отправляет `GET /api` с заголовком
   `Authorization: Basic ...` и показывает полученные задачи в `RecyclerView`.
7. **TaskAdapter** связывает список задач с элементами `RecyclerView`.
8. **Task** и **TaskApi** — модель задачи и интерфейс Retrofit для запроса к серверу.

## Запуск

1. Запустить PostgreSQL (база `todo_db`) и указать свой пароль в
   `server/src/main/resources/application.properties`.
2. Открыть папку `server` в IntelliJ IDEA и запустить `DemoApplication`.
3. Открыть папку `android-client` в IntelliJ IDEA (с установленными плагинами Android)
   или в Android Studio, дождаться синхронизации Gradle.
4. Запустить эмулятор в Device Manager и запустить приложение.
5. Войти, например, как `user` / `password` — откроется список задач.

Пользователи: `user`, `moderator`, `auditor`, `admin`, пароль у всех `password`.

## Вывод

В ходе работы было разработано клиентское приложение под Android, которое авторизуется
на сервере Spring Boot через HTTP Basic и получает список задач через REST API с помощью
библиотеки Retrofit. Задачи отображаются в списке RecyclerView. Получены практические
навыки разработки мобильного клиента для серверного приложения на Spring.
