package com.example.demo;

import java.time.format.DateTimeFormatter;

// Данные задачи, которые отдаются клиенту через REST API (/api).
// Используем отдельный класс, чтобы не отдавать пароль автора и не было
// бесконечной рекурсии из-за связей Task <-> SubTask / TaskHistory.
public record TaskDto(Long id,
                      String description,
                      boolean completed,
                      String createdAt,
                      String priority,
                      String category,
                      String author,
                      int subTasks) {

    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public static TaskDto from(Task task) {
        return new TaskDto(
                task.getId(),
                task.getDescription(),
                task.isCompleted(),
                task.getCreatedAt() != null ? task.getCreatedAt().format(FORMAT) : "",
                task.getPriority(),
                task.getCategory(),
                task.getUser() != null ? task.getUser().getName() : "",
                task.getSubTasks().size());
    }
}
