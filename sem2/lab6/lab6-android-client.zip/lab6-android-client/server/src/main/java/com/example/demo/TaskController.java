package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.Map;

@Controller
public class TaskController {

    @Autowired
    private TaskService taskService;

    @Autowired
    private LoginHistoryRepository loginHistoryRepository;

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("tasks", taskService.getAllTasks());
        return "index";
    }

    @PreAuthorize("hasAnyRole('USER', 'MODERATOR', 'ADMIN')")
    @PostMapping("/addTask")
    public String addTask(@ModelAttribute Task task, Principal principal) {
        taskService.addTask(task, principal.getName());
        return "redirect:/";
    }

    @PreAuthorize("hasAnyRole('MODERATOR', 'ADMIN')")
    @GetMapping("/deleteTask/{id}")
    public String deleteTask(@PathVariable Long id) {
        taskService.deleteTask(id);
        return "redirect:/";
    }

    @PreAuthorize("hasAnyRole('MODERATOR', 'ADMIN')")
    @PostMapping("/updateTask/{id}")
    public String updateTask(@PathVariable Long id, @RequestParam boolean completed) {
        taskService.updateTask(id, completed);
        return "redirect:/";
    }

    // Поиск по задачам (из ЛР2-3)
    @PreAuthorize("hasAnyRole('AUDITOR', 'ADMIN')")
    @GetMapping("/search")
    public String search(@RequestParam String query, Model model) {
        model.addAttribute("tasks", taskService.searchTasks(query));
        model.addAttribute("query", query);
        return "index";
    }

    // ===== Доп. задание: подзадачи =====

    @PreAuthorize("hasAnyRole('USER', 'MODERATOR', 'ADMIN')")
    @PostMapping("/addSubTask/{taskId}")
    public String addSubTask(@PathVariable Long taskId, @RequestParam String description) {
        taskService.addSubTask(taskId, description);
        return "redirect:/";
    }

    @PreAuthorize("hasAnyRole('MODERATOR', 'ADMIN')")
    @PostMapping("/updateSubTask/{id}")
    public String updateSubTask(@PathVariable Long id, @RequestParam boolean completed) {
        taskService.updateSubTask(id, completed);
        return "redirect:/";
    }

    // ===== Доп. задание: история входов и изменений задач (только ADMIN) =====

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/history")
    public String history(Model model) {
        model.addAttribute("logins", loginHistoryRepository.findAllByOrderByLoginDateDesc());
        model.addAttribute("changes", taskService.getTaskHistory());
        return "history";
    }

    // ===================== REST-методы для клиента (ЛР5) =====================

    // Получение всех задач с дополнительными данными из БД
    @GetMapping("/api")
    public ResponseEntity<List<TaskDto>> getAllTasksApi() {
        return ResponseEntity.ok(taskService.getAllTaskDtos());
    }

    // Информация о текущем пользователе (клиент проверяет логин и узнаёт роль)
    @GetMapping("/api/me")
    public ResponseEntity<Map<String, String>> me(Authentication authentication) {
        String role = authentication.getAuthorities().iterator().next()
                .getAuthority().replace("ROLE_", "");
        return ResponseEntity.ok(Map.of("username", authentication.getName(), "role", role));
    }

    // Доп. задание: добавление задачи из клиента
    @PreAuthorize("hasAnyRole('USER', 'MODERATOR', 'ADMIN')")
    @PostMapping("/api")
    public ResponseEntity<String> addTaskApi(@RequestBody Task task, Principal principal) {
        if (task.getDescription() == null || task.getDescription().isBlank()) {
            return ResponseEntity.badRequest().body("Description is empty");
        }
        taskService.addTask(task, principal.getName());
        return ResponseEntity.ok("Task added");
    }

    // Доп. задание: удаление задачи из клиента (только MODERATOR и ADMIN)
    @PreAuthorize("hasAnyRole('MODERATOR', 'ADMIN')")
    @DeleteMapping("/api/{id}")
    public ResponseEntity<String> deleteTaskApi(@PathVariable Long id) {
        if (!taskService.exists(id)) {
            return ResponseEntity.notFound().build();
        }
        taskService.deleteTask(id);
        return ResponseEntity.ok("Task deleted");
    }
}
