package com.example.demo;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class TaskService {

    private final TaskRepository taskRepository;
    private final SubTaskRepository subTaskRepository;
    private final TaskHistoryRepository taskHistoryRepository;
    private final UserRepository userRepository;

    public TaskService(TaskRepository taskRepository,
                       SubTaskRepository subTaskRepository,
                       TaskHistoryRepository taskHistoryRepository,
                       UserRepository userRepository) {
        this.taskRepository = taskRepository;
        this.subTaskRepository = subTaskRepository;
        this.taskHistoryRepository = taskHistoryRepository;
        this.userRepository = userRepository;
    }

    public List<Task> getAllTasks() {
        return taskRepository.findAll(Sort.by("id"));
    }

    // Задачи для REST API (ЛР5)
    @Transactional(readOnly = true)
    public List<TaskDto> getAllTaskDtos() {
        return taskRepository.findAll(Sort.by("id")).stream().map(TaskDto::from).toList();
    }

    public boolean exists(Long id) {
        return taskRepository.existsById(id);
    }

    public List<Task> searchTasks(String query) {
        return taskRepository.findByDescriptionContainingIgnoreCaseOrderById(query);
    }

    // Добавление задачи: запоминаем автора и пишем запись в историю
    @Transactional
    public void addTask(Task task, String username) {
        task.setUser(userRepository.findByName(username).orElse(null));
        taskRepository.save(task);
        taskHistoryRepository.save(new TaskHistory(task, "-", status(task.isCompleted())));
    }

    // Изменение статуса: сохраняем старое и новое состояние в историю
    @Transactional
    public void updateTask(Long id, boolean completed) {
        Task task = taskRepository.findById(id).orElseThrow();
        String oldState = status(task.isCompleted());
        task.setCompleted(completed);
        taskRepository.save(task);
        taskHistoryRepository.save(new TaskHistory(task, oldState, status(completed)));
    }

    // При удалении задачи её подзадачи и история удаляются каскадно
    public void deleteTask(Long id) {
        taskRepository.deleteById(id);
    }

    @Transactional
    public void addSubTask(Long taskId, String description) {
        Task task = taskRepository.findById(taskId).orElseThrow();
        SubTask subTask = new SubTask();
        subTask.setDescription(description);
        subTask.setTask(task);
        subTaskRepository.save(subTask);
    }

    @Transactional
    public void updateSubTask(Long id, boolean completed) {
        SubTask subTask = subTaskRepository.findById(id).orElseThrow();
        subTask.setCompleted(completed);
        subTaskRepository.save(subTask);
    }

    public List<TaskHistory> getTaskHistory() {
        return taskHistoryRepository.findAllByOrderByChangeDateDesc();
    }

    private String status(boolean completed) {
        return completed ? "Completed" : "Pending";
    }
}
