package com.example.myapplication;

public class Task {
    private String description;

    public String getDescription() {
        return description;
    }
}
