package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TaskService {

    private final TaskRepository taskRepository;

    @Autowired
    public TaskService(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    // Метод для добавления новой задачи
    public void addTask(Task task) {
        taskRepository.addTask(task);
    }

    // Метод для получения всех задач
    public List<Task> getAllTasks() {
        return taskRepository.getAllTasks();
    }

    // Метод для удаления задачи по её идентификатору
    public void deleteTask(Long id) {
        taskRepository.deleteTask(id);
    }

    // Метод для обновления статуса задачи
    public void updateTask(Long id, boolean completed) {
        taskRepository.updateTask(id, completed);
    }

    // Доп. задание (вариант 5): поиск задач
    public List<Task> searchTasks(String query) {
        return taskRepository.searchTasks(query);
    }
}
