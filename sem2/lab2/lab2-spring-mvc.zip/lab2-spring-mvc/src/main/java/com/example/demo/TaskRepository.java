package com.example.demo;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class TaskRepository {

    private List<Task> taskList = new ArrayList<>();

    // Метод для добавления задачи в репозиторий
    public void addTask(Task task) {
        taskList.add(task);
    }

    // Метод для получения всех задач из репозитория
    public List<Task> getAllTasks() {
        return taskList;
    }

    // Метод для удаления задачи из репозитория по её идентификатору
    public void deleteTask(Long id) {
        taskList.removeIf(task -> task.getId().equals(id));
    }

    // Метод для обновления статуса задачи
    public void updateTask(Long id, boolean completed) {
        for (Task task : taskList) {
            if (task.getId().equals(id)) {
                task.setCompleted(completed);
                break;
            }
        }
    }

    // Доп. задание (вариант 5): поиск задач по названию или описанию
    public List<Task> searchTasks(String query) {
        List<Task> result = new ArrayList<>();
        String q = query.toLowerCase();
        for (Task task : taskList) {
            String title = task.getTitle() == null ? "" : task.getTitle().toLowerCase();
            String description = task.getDescription() == null ? "" : task.getDescription().toLowerCase();
            if (title.contains(q) || description.contains(q)) {
                result.add(task);
            }
        }
        return result;
    }
}
