# Лабораторная работа №2. Spring MVC

**Цель работы:** получить практические навыки работы с Spring Framework.

## Описание

Веб-приложение для управления задачами (ToDo List) на Spring Boot с использованием
архитектуры MVC и шаблонизатора Thymeleaf. Пользователь может добавлять задачи,
удалять их, отмечать как выполненные и искать задачи по тексту.
Задачи хранятся в памяти приложения.

- Язык: Java 21
- Сборка: Maven
- Spring Boot: 3.2.3
- Зависимости: `spring-boot-starter-web`, `spring-boot-starter-thymeleaf`

## Структура проекта

```
lab2-spring-mvc/
├── pom.xml
└── src/main/
    ├── java/com/example/demo/
    │   ├── DemoApplication.java   — точка входа в приложение
    │   ├── Task.java              — модель задачи (Model)
    │   ├── TaskRepository.java    — слой доступа к данным
    │   ├── TaskService.java       — сервисный слой (бизнес-логика)
    │   └── TaskController.java    — контроллер (Controller)
    └── resources/
        ├── application.properties
        └── templates/
            └── index.html         — представление (View)
```

## Компоненты MVC

- **Model** — класс `Task`: id, название, описание, статус выполнения.
- **View** — шаблон `index.html` (Thymeleaf): список задач, форма добавления, поиск.
- **Controller** — класс `TaskController`: обрабатывает запросы и через `TaskService`
  работает с `TaskRepository`.

## Обрабатываемые запросы

| Метод | URL                  | Описание                                |
|-------|----------------------|-----------------------------------------|
| GET   | `/`                  | Главная страница со списком задач       |
| POST  | `/addTask`           | Добавление новой задачи                 |
| GET   | `/deleteTask/{id}`   | Удаление задачи по id                   |
| POST  | `/updateTask/{id}`   | Отметка задачи как выполненной          |
| GET   | `/search?query=...`  | Поиск задач *(доп. задание)*            |

После добавления, удаления и обновления выполняется `redirect:/` на главную страницу.

## Дополнительное задание

### Вариант 3 — подтверждение удаления

Перед удалением задачи появляется окно подтверждения. Если пользователь нажмёт «Отмена»,
задача не удаляется.

```html
<a th:href="@{/deleteTask/{id}(id=${task.id})}"
   onclick="return confirm('Are you sure you want to delete this task?');">Delete</a>
```

### Вариант 5 — поиск по задачам

На странице добавлена форма поиска. Поиск идёт по названию и описанию задачи
без учёта регистра. Кнопка **Reset** возвращает полный список.

```java
@GetMapping("/search")
public String search(@RequestParam String query, Model model) {
    model.addAttribute("tasks", taskService.searchTasks(query));
    model.addAttribute("query", query);
    return "index";
}
```

Метод `searchTasks` добавлен в `TaskService` и `TaskRepository`.

## Запуск

1. Открыть проект в IntelliJ IDEA как Maven-проект.
2. Запустить класс `DemoApplication`.
3. Открыть в браузере http://localhost:8080

## Вывод

В ходе работы было разработано веб-приложение ToDo List на Spring Boot по архитектуре MVC.
Созданы модель `Task`, слой доступа к данным `TaskRepository`, сервисный слой `TaskService`,
контроллер `TaskController` и представление `index.html` на Thymeleaf. Дополнительно
реализованы подтверждение удаления задачи и поиск по задачам. Получены практические
навыки работы со Spring MVC.
