package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class TaskController {

    private final TaskService taskService;

    @Autowired
    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    // Просмотр списка задач - доступен всем авторизованным пользователям
    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("tasks", taskService.getAllTasks());
        return "index";
    }

    // Добавление задачи - USER, MODERATOR, ADMIN (AUDITOR не может)
    @PreAuthorize("hasAnyRole('USER', 'MODERATOR', 'ADMIN')")
    @PostMapping("/addTask")
    public String addTask(@ModelAttribute Task task) {
        taskService.addTask(task);
        return "redirect:/";
    }

    // Удаление задачи (с подтверждением из ЛР2) - MODERATOR, ADMIN
    @PreAuthorize("hasAnyRole('MODERATOR', 'ADMIN')")
    @GetMapping("/deleteTask/{id}")
    public String deleteTask(@PathVariable Long id) {
        taskService.deleteTask(id);
        return "redirect:/";
    }

    // Изменение статуса задачи - MODERATOR, ADMIN
    @PreAuthorize("hasAnyRole('MODERATOR', 'ADMIN')")
    @PostMapping("/updateTask/{id}")
    public String updateTask(@PathVariable Long id, @RequestParam boolean completed) {
        taskService.updateTask(id, completed);
        return "redirect:/";
    }

    // Поиск по задачам (функционал из ЛР2) - AUDITOR, ADMIN
    @PreAuthorize("hasAnyRole('AUDITOR', 'ADMIN')")
    @GetMapping("/search")
    public String search(@RequestParam String query, Model model) {
        model.addAttribute("tasks", taskService.searchTasks(query));
        model.addAttribute("query", query);
        return "index";
    }
}
