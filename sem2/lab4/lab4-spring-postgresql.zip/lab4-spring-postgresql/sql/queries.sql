-- 1. Создание базы данных (выполнить один раз в pgAdmin)
CREATE DATABASE todo_db;

-- Таблицы создаются автоматически при запуске приложения (spring.jpa.hibernate.ddl-auto=update).
-- Запросы для проверки данных в pgAdmin (Query Tool для базы todo_db):

SELECT * FROM tasks;
SELECT * FROM sub_tasks;
SELECT * FROM users;
SELECT * FROM login_history;
SELECT * FROM task_history;

-- Задачи вместе с автором
SELECT t.id, t.description, t.category, t.priority, t.created_at, u.name AS author
FROM tasks t
LEFT JOIN users u ON u.id = t.user_id;

-- Подзадачи вместе с родительской задачей
SELECT s.id, s.description, s.completed, t.description AS parent_task
FROM sub_tasks s
JOIN tasks t ON t.id = s.task_id;
