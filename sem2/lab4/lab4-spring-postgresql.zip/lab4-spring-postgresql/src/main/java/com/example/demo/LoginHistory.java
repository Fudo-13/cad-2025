package com.example.demo;

import jakarta.persistence.*;

import java.time.LocalDateTime;

// Доп. задание: история входов (ID, дата входа, ID пользователя, IP-адрес)
@Entity
@Table(name = "login_history")
public class LoginHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private LocalDateTime loginDate;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private AppUser user;

    private String ipAddress;

    public LoginHistory() {
    }

    public LoginHistory(LocalDateTime loginDate, AppUser user, String ipAddress) {
        this.loginDate = loginDate;
        this.user = user;
        this.ipAddress = ipAddress;
    }

    public Long getId() {
        return id;
    }

    public LocalDateTime getLoginDate() {
        return loginDate;
    }

    public AppUser getUser() {
        return user;
    }

    public String getIpAddress() {
        return ipAddress;
    }
}
