package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

// При первом запуске заполняет таблицу users теми же пользователями, что были в ЛР3
@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        if (userRepository.count() == 0) {
            String password = passwordEncoder.encode("password");
            userRepository.save(new AppUser("user", "user@example.com", password, "USER"));
            userRepository.save(new AppUser("moderator", "moderator@example.com", password, "MODERATOR"));
            userRepository.save(new AppUser("auditor", "auditor@example.com", password, "AUDITOR"));
            userRepository.save(new AppUser("admin", "admin@example.com", password, "ADMIN"));
        }
    }
}
