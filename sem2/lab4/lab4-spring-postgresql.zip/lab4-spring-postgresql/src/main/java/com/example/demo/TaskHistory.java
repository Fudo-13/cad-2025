package com.example.demo;

import jakarta.persistence.*;

import java.time.LocalDateTime;

// Доп. задание: история изменений задачи (ID, дата изменения, старое и новое состояние, ID задачи)
@Entity
@Table(name = "task_history")
public class TaskHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private LocalDateTime changeDate;
    private String oldState;
    private String newState;

    @ManyToOne
    @JoinColumn(name = "task_id")
    private Task task;

    public TaskHistory() {
    }

    public TaskHistory(Task task, String oldState, String newState) {
        this.task = task;
        this.oldState = oldState;
        this.newState = newState;
        this.changeDate = LocalDateTime.now();
    }

    public Long getId() {
        return id;
    }

    public LocalDateTime getChangeDate() {
        return changeDate;
    }

    public String getOldState() {
        return oldState;
    }

    public String getNewState() {
        return newState;
    }

    public Task getTask() {
        return task;
    }
}
