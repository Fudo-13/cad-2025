package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TaskRepository extends JpaRepository<Task, Long> {

    // Поиск по описанию (функционал из ЛР2)
    List<Task> findByDescriptionContainingIgnoreCaseOrderById(String text);
}
