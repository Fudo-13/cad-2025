package com.example.demo;

import jakarta.persistence.*;

// Доп. задание: пользователь (ID, имя, email, пароль)
// Таблица называется "users", потому что "user" - зарезервированное слово в PostgreSQL
@Entity
@Table(name = "users")
public class AppUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true)
    private String name;
    private String email;
    private String password; // хранится в зашифрованном виде (BCrypt)
    private String role;     // роль для Spring Security (USER, MODERATOR, AUDITOR, ADMIN)

    public AppUser() {
    }

    public AppUser(String name, String email, String password, String role) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
