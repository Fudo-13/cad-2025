# Лабораторная работа №4. Взаимодействие Spring и PostgreSQL

**Цель работы:** получить практические навыки работы с Spring Framework.

## Описание

Приложение ToDo List из лабораторной работы №3 (Spring Security) переведено с хранения
задач в памяти на хранение в базе данных PostgreSQL с помощью Spring Data JPA (Hibernate).
Таблицы создаются автоматически при запуске (`spring.jpa.hibernate.ddl-auto=update`).

- Язык: Java 21
- Сборка: Maven
- Spring Boot: 3.2.3
- СУБД: PostgreSQL
- Зависимости: `spring-boot-starter-web`, `spring-boot-starter-thymeleaf`,
  `spring-boot-starter-security`, `spring-boot-starter-data-jpa`, `postgresql`

## Структура проекта

```
lab4-spring-postgresql/
├── pom.xml
├── sql/queries.sql                    — создание БД и запросы для проверки
└── src/main/
    ├── java/com/example/demo/
    │   ├── DemoApplication.java
    │   ├── Task.java                  — сущность задачи (таблица tasks)
    │   ├── SubTask.java               — сущность подзадачи (sub_tasks)
    │   ├── AppUser.java               — сущность пользователя (users)
    │   ├── LoginHistory.java          — история входов (login_history)
    │   ├── TaskHistory.java           — история изменений задач (task_history)
    │   ├── TaskRepository.java        — репозитории Spring Data JPA
    │   ├── SubTaskRepository.java
    │   ├── UserRepository.java
    │   ├── LoginHistoryRepository.java
    │   ├── TaskHistoryRepository.java
    │   ├── TaskService.java           — сервисный слой
    │   ├── TaskController.java        — контроллер
    │   ├── SecurityConfig.java        — настройки безопасности
    │   ├── LoginSuccessHandler.java   — запись входов в login_history
    │   └── DataInitializer.java       — создание пользователей при первом запуске
    └── resources/
        ├── application.properties     — подключение к БД
        └── templates/
            ├── index.html             — список задач
            └── history.html           — история входов и изменений
```

## Основная часть (по примеру)

1. В pgAdmin создана база данных `todo_db`.
2. В `application.properties` настроено подключение к PostgreSQL.
3. В `pom.xml` добавлены зависимости `spring-boot-starter-data-jpa` и `postgresql`.
4. Класс `Task` превращён в JPA-сущность (`@Entity`, `@Id`, `@GeneratedValue`).
5. `TaskRepository` стал интерфейсом, наследующим `JpaRepository<Task, Long>`.
6. Контроллер работает с базой данных: `findAll()`, `save()`, `deleteById()`, `findById()`.
7. На странице кнопка статуса переключает задачу между Completed и Pending.

## Дополнительное задание

1. **Дополнительные сведения о задаче.** В таблицу `tasks` добавлены поля
   `created_at` (время создания, заполняется автоматически через `@PrePersist`),
   `priority` (Low / Medium / High) и `category` (Study / Work / Personal).
2. **Таблица `sub_tasks`** (ID, описание, статус, ID родительской задачи).
   Связь «один ко многим»: `@OneToMany` в `Task` и `@ManyToOne` в `SubTask`.
   Подзадачи добавляются прямо под задачей на главной странице.
3. **Таблица `users`** (ID, имя, email, пароль, роль). Пользователи для входа теперь
   берутся из базы данных, пароли хранятся в виде хеша BCrypt. Таблицы `tasks` и `users`
   связаны через `user_id`: у каждой задачи сохраняется автор.
   Таблица названа `users`, потому что `user` — зарезервированное слово в PostgreSQL.
4. **Таблица `login_history`** (ID, дата входа, ID пользователя, IP-адрес).
   Запись добавляется при каждом успешном входе (`LoginSuccessHandler`).
5. **Таблица `task_history`** (ID, дата изменения, старое и новое состояние, ID задачи).
   Запись добавляется при создании задачи и при каждом изменении её статуса.

Историю входов и изменений можно посмотреть на странице `/history` (только для ADMIN)
или запросами из `sql/queries.sql` в pgAdmin.

## Схема базы данных

```
users (id, name, email, password, role)
  │ 1
  ├──< tasks (id, description, completed, created_at, priority, category, user_id)
  │       │ 1
  │       ├──< sub_tasks (id, description, completed, task_id)
  │       └──< task_history (id, change_date, old_state, new_state, task_id)
  │
  └──< login_history (id, login_date, user_id, ip_address)
```

## Пользователи

Создаются автоматически при первом запуске, если таблица `users` пуста.

| Логин       | Пароль     | Роль      | Права                                              |
|-------------|------------|-----------|----------------------------------------------------|
| `user`      | `password` | USER      | просмотр, добавление задач и подзадач              |
| `moderator` | `password` | MODERATOR | + удаление и изменение статуса                     |
| `auditor`   | `password` | AUDITOR   | просмотр и поиск                                   |
| `admin`     | `password` | ADMIN     | всё, включая поиск и страницу истории `/history`   |

## Запуск

1. Установить PostgreSQL и pgAdmin 4, создать базу данных `todo_db`.
2. В `src/main/resources/application.properties` указать свой пароль от PostgreSQL
   в строке `spring.datasource.password=`.
3. Открыть проект в IntelliJ IDEA как Maven-проект и запустить `DemoApplication`.
4. Открыть http://localhost:8080 и войти, например, как `admin` / `password`.
5. Добавить задачи и подзадачи, изменить статус, затем проверить данные в pgAdmin.

## Вывод

В ходе работы приложение ToDo List подключено к базе данных PostgreSQL с помощью
Spring Data JPA и Hibernate. Задачи теперь хранятся в БД и не теряются после перезапуска.
Дополнительно добавлены поля времени создания, приоритета и категории, таблицы подзадач,
пользователей, истории входов и истории изменений задач со связями между ними.
Получены практические навыки работы со Spring и PostgreSQL.
